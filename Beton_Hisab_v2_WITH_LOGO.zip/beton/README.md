# Beton Hisab v2

Offline-first Android salary and overtime tracker in Kotlin + Jetpack Compose.

## Included features
- Daily salary, overtime, bonus, deduction, advance and notes
- Automatic overtime and daily total calculation
- Calendar view
- Monthly and yearly summaries
- Daily income chart
- History with edit/delete
- PDF monthly report
- Local JSON backup and restore
- Default salary and overtime settings
- Room/SQLite local database
- No Firebase, cloud API or INTERNET permission

## Build
Use the included GitHub Actions workflow or Android Studio/compatible Gradle environment.
