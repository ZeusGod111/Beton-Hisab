package com.betonhisab.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.betonhisab.app.data.local.BetonDatabase
import com.betonhisab.app.data.local.SalaryEntry
import com.betonhisab.app.data.repository.SalaryRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*


data class MonthlyReport(
    val workingDays: Int = 0,
    val regularSalaryTotal: Double = 0.0,
    val totalOvertimeHours: Double = 0.0,
    val overtimeIncomeTotal: Double = 0.0,
    val bonusTotal: Double = 0.0,
    val deductionTotal: Double = 0.0,
    val advanceTotal: Double = 0.0,
    val finalTotalIncome: Double = 0.0
)

class SalaryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: SalaryRepository
    val allEntries: StateFlow<List<SalaryEntry>>
    private val _selectedMonth = MutableStateFlow(getCurrentMonthKey())
    val selectedMonth: StateFlow<String> = _selectedMonth.asStateFlow()
    private val prefs = application.getSharedPreferences("beton_prefs", Application.MODE_PRIVATE)

    var defaultDailySalary: Double
        get() = prefs.getFloat("default_daily_salary", 800f).toDouble()
        set(value) = prefs.edit().putFloat("default_daily_salary", value.toFloat()).apply()
    var defaultOvertimeRate: Double
        get() = prefs.getFloat("default_ot_rate", 100f).toDouble()
        set(value) = prefs.edit().putFloat("default_ot_rate", value.toFloat()).apply()

    init {
        repository = SalaryRepository(BetonDatabase.getDatabase(application).salaryDao())
        allEntries = repository.allEntries.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    val currentMonthEntries: StateFlow<List<SalaryEntry>> = combine(allEntries, _selectedMonth) { entries, month ->
        entries.filter { it.date.startsWith(month) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val monthlyReport: StateFlow<MonthlyReport> = currentMonthEntries.map { list ->
        val regular = list.sumOf { it.dailySalary }
        val otHours = list.sumOf { it.overtimeHours }
        val otIncome = list.sumOf { it.overtimePay }
        val bonus = list.sumOf { it.bonus }
        val deduction = list.sumOf { it.deduction }
        val advance = list.sumOf { it.advance }
        val days = list.count { it.dailySalary > 0 || it.overtimeHours > 0 }
        MonthlyReport(days, regular, otHours, otIncome, bonus, deduction, advance, regular + otIncome + bonus - deduction - advance)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MonthlyReport())

    fun setSelectedMonth(monthKey: String) { _selectedMonth.value = monthKey }

    fun shiftMonth(delta: Int) {
        val cal = Calendar.getInstance().apply {
            time = SimpleDateFormat("yyyy-MM", Locale.US).parse(_selectedMonth.value) ?: Date()
            add(Calendar.MONTH, delta)
        }
        _selectedMonth.value = SimpleDateFormat("yyyy-MM", Locale.US).format(cal.time)
    }

    fun addOrUpdateEntry(
        id: Long = 0,
        date: String,
        salary: Double,
        otHours: Double,
        otRate: Double,
        bonus: Double,
        deduction: Double,
        advance: Double,
        note: String
    ) = viewModelScope.launch {
        val entry = SalaryEntry(id, date, salary, otHours, otRate, bonus, deduction, advance, note)
        if (id == 0L) repository.insert(entry) else repository.update(entry)
    }

    fun deleteEntry(entry: SalaryEntry) = viewModelScope.launch { repository.delete(entry) }

    fun backupJson(): String {
        val array = JSONArray()
        allEntries.value.forEach { e ->
            array.put(JSONObject().apply {
                put("id", e.id); put("date", e.date); put("dailySalary", e.dailySalary)
                put("overtimeHours", e.overtimeHours); put("overtimeRate", e.overtimeRate)
                put("bonus", e.bonus); put("deduction", e.deduction); put("advance", e.advance)
                put("note", e.note); put("createdAt", e.createdAt)
            })
        }
        return array.toString()
    }

    fun restoreJson(json: String, onDone: (Int) -> Unit = {}) = viewModelScope.launch {
        runCatching {
            val array = JSONArray(json)
            var count = 0
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                repository.insert(SalaryEntry(
                    id = 0,
                    date = o.optString("date"),
                    dailySalary = o.optDouble("dailySalary", 0.0),
                    overtimeHours = o.optDouble("overtimeHours", 0.0),
                    overtimeRate = o.optDouble("overtimeRate", defaultOvertimeRate),
                    bonus = o.optDouble("bonus", 0.0),
                    deduction = o.optDouble("deduction", 0.0),
                    advance = o.optDouble("advance", 0.0),
                    note = o.optString("note"),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                ))
                count++
            }
            count
        }.onSuccess { onDone(it) }.onFailure { onDone(-1) }
    }

    companion object {
        fun getCurrentMonthKey(): String = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())
    }
}
