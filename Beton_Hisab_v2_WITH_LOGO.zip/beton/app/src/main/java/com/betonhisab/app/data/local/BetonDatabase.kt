package com.betonhisab.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [SalaryEntry::class], version = 2, exportSchema = false)
abstract class BetonDatabase : RoomDatabase() {
    abstract fun salaryDao(): SalaryDao

    companion object {
        @Volatile private var INSTANCE: BetonDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE salary_entries ADD COLUMN advance REAL NOT NULL DEFAULT 0.0")
            }
        }

        fun getDatabase(context: Context): BetonDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BetonDatabase::class.java,
                    "beton_hisab_local.db"
                ).addMigrations(MIGRATION_1_2).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
