package com.betonhisab.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.betonhisab.app.ui.screens.*
import com.betonhisab.app.ui.theme.BetonHisabTheme
import com.betonhisab.app.ui.viewmodel.SalaryViewModel

private enum class Screen(val title: String, val icon: ImageVector) {
    Home("হোম", Icons.Default.Home), Calendar("ক্যালেন্ডার", Icons.Default.CalendarMonth),
    History("ইতিহাস", Icons.Default.History), Report("রিপোর্ট", Icons.Default.Assessment), Settings("সেটিংস", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    private val viewModel: SalaryViewModel by viewModels()
    private var pendingRestore = false

    private val restoreLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader -> viewModel.restoreJson(reader.readText()) }
    }

    private val createFileLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/json")) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(viewModel.backupJson()) }
    }

    private val createPdfLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        createPdfReport(this, uri, viewModel.selectedMonth.value, viewModel.currentMonthEntries.value, viewModel.monthlyReport.value)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BetonHisabTheme {
                var currentScreen by remember { mutableStateOf(Screen.Home) }
                var showAddDialog by remember { mutableStateOf(false) }
                Scaffold(
                    bottomBar = { NavigationBar { Screen.values().forEach { s ->
                        NavigationBarItem(currentScreen == s, { currentScreen = s }, { Icon(s.icon, s.title) }, label = { Text(s.title) })
                    } } },
                    floatingActionButton = { FloatingActionButton({ showAddDialog = true }) { Icon(Icons.Default.Add, "যোগ করুন") } }
                ) { padding ->
                    Box(Modifier.padding(padding)) {
                        when (currentScreen) {
                            Screen.Home -> HomeScreen(viewModel) { showAddDialog = true }
                            Screen.Calendar -> CalendarScreen(viewModel) { showAddDialog = true }
                            Screen.History -> HistoryScreen(viewModel)
                            Screen.Report -> ReportScreen(viewModel) { createPdfLauncher.launch("Beton-Hisab-${viewModel.selectedMonth.value}.pdf") }
                            Screen.Settings -> SettingsScreen(
                                viewModel,
                                onBackup = { createFileLauncher.launch("Beton-Hisab-Backup.json") },
                                onRestore = { restoreLauncher.launch(arrayOf("application/json", "text/*", "application/octet-stream")) }
                            )
                        }
                    }
                    if (showAddDialog) AddDailyEntryDialog(viewModel, { showAddDialog = false })
                }
            }
        }
    }
}
