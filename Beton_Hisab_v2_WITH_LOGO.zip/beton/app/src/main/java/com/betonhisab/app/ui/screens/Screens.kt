package com.betonhisab.app.ui.screens

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.betonhisab.app.data.local.SalaryEntry
import com.betonhisab.app.ui.viewmodel.MonthlyReport
import com.betonhisab.app.ui.viewmodel.SalaryViewModel
import java.text.SimpleDateFormat
import java.util.*

private val bdLocale = Locale("bn", "BD")
private val displayDate = SimpleDateFormat("d MMMM, yyyy (EEEE)", bdLocale)
private val inputDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)
private fun money(v: Double) = "৳ ${String.format(Locale.US, "%,.0f", v)}"
private fun formatDate(v: String) = runCatching { displayDate.format(inputDate.parse(v)!!) }.getOrDefault(v)
private fun monthName(key: String) = runCatching { SimpleDateFormat("MMMM yyyy", bdLocale).format(SimpleDateFormat("yyyy-MM", Locale.US).parse(key)!!) }.getOrDefault(key)

@Composable
fun HomeScreen(viewModel: SalaryViewModel, onAddClick: () -> Unit) {
    val entries by viewModel.currentMonthEntries.collectAsState(); val report by viewModel.monthlyReport.collectAsState()
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
        item { Text("বেতন হিসাব", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("দৈনিক বেতন ও ওভারটাইম ট্র্যাকার", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { SummaryCard(report) }
        item { IncomeChart(entries) }
        item { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text("এই মাসের হিসাব", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); TextButton(onClick = onAddClick) { Text("+ যোগ করুন") } } }
        items(entries.take(10), key = { it.id }) { EntryCard(it) }
    }
}

@Composable private fun SummaryCard(report: MonthlyReport) {
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
        Text("এই মাসের মোট আয়", color = MaterialTheme.colorScheme.onSurfaceVariant); Text(money(report.finalTotalIncome), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Metric("বেতন", money(report.regularSalaryTotal)); Metric("OT", money(report.overtimeIncomeTotal)); Metric("কাজ", "${report.workingDays} দিন") }
    } }
}
@Composable private fun Metric(label: String, value: String) { Column { Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, fontWeight = FontWeight.SemiBold) } }

@Composable private fun IncomeChart(entries: List<SalaryEntry>) {
    val max = (entries.maxOfOrNull { it.dailyTotal } ?: 1.0).coerceAtLeast(1.0)
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("দৈনিক আয়ের চার্ট", fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp));
        Canvas(Modifier.fillMaxWidth().height(120.dp)) { val gap = 4f; val barW = (size.width - gap * (entries.size + 1)) / entries.size.coerceAtLeast(1); entries.take(20).reversed().forEachIndexed { i, e -> val h = (e.dailyTotal / max * size.height).toFloat(); drawRect(topLeft = androidx.compose.ui.geometry.Offset(gap + i * (barW + gap), size.height - h), size = androidx.compose.ui.geometry.Size(barW.coerceAtLeast(2f), h)) } }
    } }
}

@Composable fun CalendarScreen(viewModel: SalaryViewModel, onAddClick: () -> Unit) {
    val entries by viewModel.allEntries.collectAsState(); val month by viewModel.selectedMonth.collectAsState()
    val monthEntries = entries.filter { it.date.startsWith(month) }.associateBy { it.date }
    val cal = Calendar.getInstance(); cal.time = SimpleDateFormat("yyyy-MM", Locale.US).parse(month) ?: Date(); val year = cal.get(Calendar.YEAR); val m = cal.get(Calendar.MONTH)
    val first = Calendar.getInstance().apply { set(year, m, 1) }; val start = first.get(Calendar.DAY_OF_WEEK) - 1; val days = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { IconButton({ viewModel.shiftMonth(-1) }) { Icon(Icons.Default.ChevronLeft, "আগের মাস") }; Text(monthName(month), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); IconButton({ viewModel.shiftMonth(1) }) { Icon(Icons.Default.ChevronRight, "পরের মাস") } }
        Text("তারিখে কাজ থাকলে ✓ দেখাবে", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(12.dp))
        val weeks = (start + days + 6) / 7
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { repeat(weeks) { week -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) { repeat(7) { col -> val d = week * 7 + col - start + 1; if (d in 1..days) { val key = String.format(Locale.US, "%04d-%02d-%02d", year, m + 1, d); val e = monthEntries[key]; Card(Modifier.weight(1f).height(54.dp)) { Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("$d", fontWeight = FontWeight.Bold); if (e != null) Text("✓ ${money(e.dailyTotal)}", style = MaterialTheme.typography.labelSmall) } } } else Spacer(Modifier.weight(1f).height(54.dp)) } } } }
        Spacer(Modifier.height(12.dp)); Button(onClick = onAddClick, Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("নতুন হিসাব") }
    }
}

@Composable private fun EntryCard(entry: SalaryEntry, onEdit: (() -> Unit)? = null, onDelete: (() -> Unit)? = null) {
    Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp), Arrangement.SpaceBetween, Alignment.Top) { Column(Modifier.weight(1f)) { Text(formatDate(entry.date), fontWeight = FontWeight.Bold); Text("মূল: ${money(entry.dailySalary)} • OT: ${entry.overtimeHours}h (${money(entry.overtimePay)})", color = MaterialTheme.colorScheme.onSurfaceVariant); if (entry.bonus > 0) Text("বোনাস: +${money(entry.bonus)}"); if (entry.deduction > 0) Text("কর্তন: -${money(entry.deduction)}", color = MaterialTheme.colorScheme.error); if (entry.advance > 0) Text("অ্যাডভান্স: -${money(entry.advance)}", color = MaterialTheme.colorScheme.error); if (entry.note.isNotBlank()) Text(entry.note, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Column(horizontalAlignment = Alignment.End) { Text(money(entry.dailyTotal), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); if (onEdit != null) TextButton(onClick = onEdit) { Text("সম্পাদনা") }; if (onDelete != null) TextButton(onClick = onDelete) { Text("মুছুন", color = MaterialTheme.colorScheme.error) } } } }
}

@Composable fun HistoryScreen(viewModel: SalaryViewModel) {
    val entries by viewModel.allEntries.collectAsState(); var editing by remember { mutableStateOf<SalaryEntry?>(null) }; var deleting by remember { mutableStateOf<SalaryEntry?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) { Text("ইতিহাস", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp));
        if (entries.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("এখনও কোনো হিসাব যোগ করা হয়নি") } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) { items(entries, key = { it.id }) { EntryCard(it, { editing = it }, { deleting = it }) } }
    }
    editing?.let { AddDailyEntryDialog(viewModel, { editing = null }, it) }
    deleting?.let { e -> AlertDialog(onDismissRequest = { deleting = null }, title = { Text("হিসাব মুছবেন?") }, text = { Text("${formatDate(e.date)}-এর হিসাব মুছে যাবে।") }, confirmButton = { TextButton({ viewModel.deleteEntry(e); deleting = null }) { Text("মুছুন") } }, dismissButton = { TextButton({ deleting = null }) { Text("বাতিল") } }) }
}

@Composable fun ReportScreen(viewModel: SalaryViewModel, onPdf: () -> Unit) {
    val report by viewModel.monthlyReport.collectAsState(); val month by viewModel.selectedMonth.collectAsState(); val entries by viewModel.allEntries.collectAsState(); val year = month.take(4); val yearTotal = entries.filter { it.date.startsWith(year) }.sumOf { it.dailyTotal }
    Column(Modifier.fillMaxSize().padding(16.dp)) { Text("রিপোর্ট", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { IconButton({ viewModel.shiftMonth(-1) }) { Icon(Icons.Default.ChevronLeft, "আগের মাস") }; Text(monthName(month), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); IconButton({ viewModel.shiftMonth(1) }) { Icon(Icons.Default.ChevronRight, "পরের মাস") } }
        HorizontalDivider(); ReportRow("কাজের দিন", "${report.workingDays} দিন"); ReportRow("নিয়মিত বেতন", money(report.regularSalaryTotal)); ReportRow("OT ঘণ্টা", "${report.totalOvertimeHours}"); ReportRow("OT আয়", money(report.overtimeIncomeTotal)); ReportRow("বোনাস", money(report.bonusTotal)); ReportRow("কর্তন", "- ${money(report.deductionTotal)}"); ReportRow("অ্যাডভান্স", "- ${money(report.advanceTotal)}"); HorizontalDivider(Modifier.padding(vertical = 8.dp)); ReportRow("মাসের মোট আয়", money(report.finalTotalIncome), true); ReportRow("বছরের মোট আয়", money(yearTotal), true)
        Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = onPdf, Modifier.fillMaxWidth()) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(6.dp)); Text("PDF রিপোর্ট সেভ করুন") }
    } } }
}
@Composable private fun ReportRow(label: String, value: String, bold: Boolean = false) { Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), Arrangement.SpaceBetween) { Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal); Text(value, fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold) } }

@Composable fun SettingsScreen(viewModel: SalaryViewModel, onBackup: () -> Unit, onRestore: () -> Unit) {
    var salary by remember { mutableStateOf(viewModel.defaultDailySalary.toString()) }; var otRate by remember { mutableStateOf(viewModel.defaultOvertimeRate.toString()) }; var saved by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 30.dp)) { item {
        Text("সেটিংস", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); OutlinedTextField(salary, { salary = it }, label = { Text("ডিফল্ট দৈনিক বেতন") }, prefix = { Text("৳ ") }, singleLine = true, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)); OutlinedTextField(otRate, { otRate = it }, label = { Text("ডিফল্ট OT রেট / ঘণ্টা") }, prefix = { Text("৳ ") }, singleLine = true, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(14.dp)); Button({ viewModel.defaultDailySalary = salary.toDoubleOrNull() ?: 0.0; viewModel.defaultOvertimeRate = otRate.toDoubleOrNull() ?: 0.0; saved = true }, Modifier.fillMaxWidth()) { Text("সেভ করুন") }; if (saved) Text("সেটিংস সেভ হয়েছে ✓", color = MaterialTheme.colorScheme.primary, Modifier.padding(top = 10.dp)); Spacer(Modifier.height(24.dp)); Text("ব্যাকআপ ও ডাটা", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); OutlinedButton(onBackup, Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(6.dp)); Text("ডাটা Backup (JSON)") }; Spacer(Modifier.height(8.dp)); OutlinedButton(onRestore, Modifier.fillMaxWidth()) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(6.dp)); Text("Backup Restore") }; Spacer(Modifier.height(20.dp)); Text("অ্যাপটি 100% offline। হিসাব ফোনের ভেতরেই থাকে। কোনো cloud/Firebase/API ব্যবহার করা হয়নি।", color = MaterialTheme.colorScheme.onSurfaceVariant)
    } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddDailyEntryDialog(viewModel: SalaryViewModel, onDismiss: () -> Unit, existing: SalaryEntry? = null) {
    var date by remember { mutableStateOf(existing?.date ?: inputDate.format(Date())) }; var salary by remember { mutableStateOf(existing?.dailySalary?.toString() ?: viewModel.defaultDailySalary.toString()) }; var otHours by remember { mutableStateOf(existing?.overtimeHours?.toString() ?: "0") }; var otRate by remember { mutableStateOf(existing?.overtimeRate?.toString() ?: viewModel.defaultOvertimeRate.toString()) }; var bonus by remember { mutableStateOf(existing?.bonus?.toString() ?: "0") }; var deduction by remember { mutableStateOf(existing?.deduction?.toString() ?: "0") }; var advance by remember { mutableStateOf(existing?.advance?.toString() ?: "0") }; var note by remember { mutableStateOf(existing?.note ?: "") }; var showPicker by remember { mutableStateOf(false) }
    val total = (salary.toDoubleOrNull() ?: 0.0) + (otHours.toDoubleOrNull() ?: 0.0) * (otRate.toDoubleOrNull() ?: 0.0) + (bonus.toDoubleOrNull() ?: 0.0) - (deduction.toDoubleOrNull() ?: 0.0) - (advance.toDoubleOrNull() ?: 0.0)
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "আজকের হিসাব" else "হিসাব সম্পাদনা") }, text = { Column(Modifier.fillMaxWidth()) { OutlinedButton({ showPicker = true }, Modifier.fillMaxWidth()) { Text(formatDate(date)) }; Field("দৈনিক বেতন", salary) { salary = it }; Field("OT ঘণ্টা", otHours) { otHours = it }; Field("OT রেট / ঘণ্টা", otRate) { otRate = it }; Field("বোনাস / Extra", bonus) { bonus = it }; Field("কর্তন", deduction) { deduction = it }; Field("অ্যাডভান্স", advance) { advance = it }; Field("নোট", note, false) { note = it }; Text("আজকের মোট: ${money(total)}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) } }, confirmButton = { TextButton({ viewModel.addOrUpdateEntry(existing?.id ?: 0L, date, salary.toDoubleOrNull() ?: 0.0, otHours.toDoubleOrNull() ?: 0.0, otRate.toDoubleOrNull() ?: 0.0, bonus.toDoubleOrNull() ?: 0.0, deduction.toDoubleOrNull() ?: 0.0, advance.toDoubleOrNull() ?: 0.0, note); onDismiss() }) { Text("সেভ") } }, dismissButton = { TextButton(onDismiss) { Text("বাতিল") } })
    if (showPicker) { val state = rememberDatePickerState(initialSelectedDateMillis = runCatching { inputDate.parse(date)!!.time }.getOrNull()); DatePickerDialog(onDismissRequest = { showPicker = false }, confirmButton = { TextButton(onClick = { state.selectedDateMillis?.let { date = inputDate.format(Date(it)) }; showPicker = false }) { Text("ঠিক আছে") } }, dismissButton = { TextButton(onClick = { showPicker = false }) { Text("বাতিল") } }) { DatePicker(state = state) } }
}

@Composable private fun Field(label: String, value: String, number: Boolean = true, onChange: (String) -> Unit) { OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), keyboardOptions = if (number) androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal) else androidx.compose.foundation.text.KeyboardOptions.Default) }

fun createPdfReport(context: Context, uri: Uri, month: String, entries: List<SalaryEntry>, report: MonthlyReport) {
    val pdf = PdfDocument(); val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create()); val c = page.canvas; val p = Paint().apply { textSize = 18f }; var y = 50f
    c.drawText("Beton Hisab - Salary Report", 40f, y, p); y += 28; p.textSize = 14f; c.drawText("Month: $month", 40f, y, p); y += 28
    listOf("Working days: ${report.workingDays}", "Regular salary: ${money(report.regularSalaryTotal)}", "OT: ${report.totalOvertimeHours} h / ${money(report.overtimeIncomeTotal)}", "Bonus: ${money(report.bonusTotal)}", "Deduction: ${money(report.deductionTotal)}", "Advance: ${money(report.advanceTotal)}", "TOTAL: ${money(report.finalTotalIncome)}").forEach { c.drawText(it, 40f, y, p); y += 24 }
    y += 10; p.textSize = 11f; entries.sortedBy { it.date }.forEach { if (y < 810) { c.drawText("${it.date}   ${money(it.dailyTotal)}   OT ${it.overtimeHours}h", 40f, y, p); y += 18 } }
    pdf.finishPage(page); context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }; pdf.close()
}
