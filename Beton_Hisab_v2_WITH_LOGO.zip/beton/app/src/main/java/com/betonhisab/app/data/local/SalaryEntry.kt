package com.betonhisab.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "salary_entries")
data class SalaryEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String,
    val dailySalary: Double,
    val overtimeHours: Double,
    val overtimeRate: Double,
    val bonus: Double = 0.0,
    val deduction: Double = 0.0,
    val advance: Double = 0.0,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val overtimePay: Double get() = overtimeHours * overtimeRate
    val dailyTotal: Double get() = dailySalary + overtimePay + bonus - deduction - advance
}
