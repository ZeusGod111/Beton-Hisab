# No custom ProGuard rules are required for the debug/local-first app.
