package com.betonhisab.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [SalaryEntry::class], version = 1, exportSchema = false)
abstract class BetonDatabase : RoomDatabase() {

    abstract fun salaryDao(): SalaryDao

    companion object {
        @Volatile
        private var INSTANCE: BetonDatabase? = null

        fun getDatabase(context: Context): BetonDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BetonDatabase::class.java,
                    "beton_hisab_local.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
