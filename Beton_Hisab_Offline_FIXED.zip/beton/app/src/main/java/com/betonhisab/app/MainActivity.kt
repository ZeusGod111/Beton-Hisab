package com.betonhisab.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.betonhisab.app.ui.screens.*
import com.betonhisab.app.ui.theme.BetonHisabTheme
import com.betonhisab.app.ui.viewmodel.SalaryViewModel

enum class Screen(val title: String, val icon: ImageVector) {
    Home("হোম", Icons.Default.Home),
    History("ইতিহাস", Icons.Default.History),
    Report("রিপোর্ট", Icons.Default.Assessment),
    Settings("সেটিংস", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: SalaryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BetonHisabTheme {
                var currentScreen by remember { mutableStateOf(Screen.Home) }
                var showAddDialog by remember { mutableStateOf(false) }

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            Screen.values().forEach { screen ->
                                NavigationBarItem(
                                    selected = currentScreen == screen,
                                    onClick = { currentScreen = screen },
                                    icon = { Icon(screen.icon, contentDescription = screen.title) },
                                    label = { Text(screen.title) }
                                )
                            }
                        }
                    },
                    floatingActionButton = {
                        FloatingActionButton(
                            onClick = { showAddDialog = true },
                            containerColor = MaterialTheme.colorScheme.primary
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Daily Entry")
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            Screen.Home -> HomeScreen(viewModel, onAddClick = { showAddDialog = true })
                            Screen.History -> HistoryScreen(viewModel)
                            Screen.Report -> ReportScreen(viewModel)
                            Screen.Settings -> SettingsScreen(viewModel)
                        }
                    }

                    if (showAddDialog) {
                        AddDailyEntryDialog(
                            viewModel = viewModel,
                            onDismiss = { showAddDialog = false }
                        )
                    }
                }
            }
        }
    }
}
