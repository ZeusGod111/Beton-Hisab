package com.betonhisab.app.data.repository

import com.betonhisab.app.data.local.SalaryDao
import com.betonhisab.app.data.local.SalaryEntry
import kotlinx.coroutines.flow.Flow

class SalaryRepository(private val salaryDao: SalaryDao) {

    val allEntries: Flow<List<SalaryEntry>> = salaryDao.getAllEntries()

    fun getEntriesForMonth(monthPrefix: String): Flow<List<SalaryEntry>> {
        return salaryDao.getEntriesByMonth(monthPrefix)
    }

    suspend fun insert(entry: SalaryEntry): Long = salaryDao.insertEntry(entry)

    suspend fun update(entry: SalaryEntry) = salaryDao.updateEntry(entry)

    suspend fun delete(entry: SalaryEntry) = salaryDao.deleteEntry(entry)

    suspend fun deleteById(id: Long) = salaryDao.deleteById(id)

    suspend fun clearAll() = salaryDao.clearAll()
}
