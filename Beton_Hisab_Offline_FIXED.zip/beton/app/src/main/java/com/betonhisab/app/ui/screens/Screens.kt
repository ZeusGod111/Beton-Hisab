package com.betonhisab.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.betonhisab.app.data.local.SalaryEntry
import com.betonhisab.app.ui.viewmodel.MonthlyReport
import com.betonhisab.app.ui.viewmodel.SalaryViewModel
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

private val bdLocale = Locale("bn", "BD")
private val displayDate = SimpleDateFormat("d MMMM, yyyy (EEEE)", bdLocale)
private val inputDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)

private fun money(value: Double): String = "৳ ${String.format(Locale.US, "%,.0f", value)}"
private fun formatDate(value: String): String = runCatching { displayDate.format(inputDate.parse(value)!!) }.getOrDefault(value)

@Composable
fun HomeScreen(viewModel: SalaryViewModel, onAddClick: () -> Unit) {
    val entries by viewModel.currentMonthEntries.collectAsState()
    val report by viewModel.monthlyReport.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("বেতন হিসাব", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("দৈনিক বেতন ও ওভারটাইম ট্র্যাকার", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        SummaryCard(report)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("এই মাসের হিসাব", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            TextButton(onClick = onAddClick) { Text("+ যোগ করুন") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
            items(entries, key = { it.id }) { entry -> EntryCard(entry) }
        }
    }
}

@Composable
private fun SummaryCard(report: MonthlyReport) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("এই মাসের মোট আয়", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(money(report.finalTotalIncome), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Metric("বেতন", money(report.regularSalaryTotal))
                Metric("OT", money(report.overtimeIncomeTotal))
                Metric("OT ঘণ্টা", "${report.totalOvertimeHours}")
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column { Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun EntryCard(entry: SalaryEntry, onEdit: (() -> Unit)? = null, onDelete: (() -> Unit)? = null) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(formatDate(entry.date), fontWeight = FontWeight.Bold)
                    Text("মূল: ${money(entry.dailySalary)}  •  OT: ${entry.overtimeHours}h (${money(entry.overtimePay)})", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (entry.bonus > 0) Text("• বোনাস: +${money(entry.bonus)}")
                    if (entry.deduction > 0) Text("• কর্তন: -${money(entry.deduction)}", color = MaterialTheme.colorScheme.error)
                    if (entry.note.isNotBlank()) Text(entry.note, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(money(entry.dailyTotal), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    if (onEdit != null) TextButton(onClick = onEdit) { Text("সম্পাদনা") }
                    if (onDelete != null) TextButton(onClick = onDelete) { Text("মুছুন", color = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(viewModel: SalaryViewModel) {
    val entries by viewModel.allEntries.collectAsState()
    var editing by remember { mutableStateOf<SalaryEntry?>(null) }
    var deleting by remember { mutableStateOf<SalaryEntry?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("ইতিহাস", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("এখনও কোনো হিসাব যোগ করা হয়নি") }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(entries, key = { it.id }) { entry -> EntryCard(entry, { editing = entry }, { deleting = entry }) }
            }
        }
    }
    editing?.let { entry -> AddDailyEntryDialog(viewModel, onDismiss = { editing = null }, existing = entry) }
    deleting?.let { entry ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("হিসাব মুছবেন?") },
            text = { Text("${formatDate(entry.date)}-এর হিসাব মুছে যাবে।") },
            confirmButton = { TextButton(onClick = { viewModel.deleteEntry(entry); deleting = null }) { Text("মুছুন") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("বাতিল") } }
        )
    }
}

@Composable
fun ReportScreen(viewModel: SalaryViewModel) {
    val report by viewModel.monthlyReport.collectAsState()
    val month by viewModel.selectedMonth.collectAsState()
    val monthName = runCatching { SimpleDateFormat("MMMM yyyy", bdLocale).format(SimpleDateFormat("yyyy-MM", Locale.US).parse(month)!!) }.getOrDefault(month)
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("রিপোর্ট", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.shiftMonth(-1) }) { Icon(Icons.Default.ChevronLeft, "আগের মাস") }
                    Text(monthName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { viewModel.shiftMonth(1) }) { Icon(Icons.Default.ChevronRight, "পরের মাস") }
                }
                HorizontalDivider()
                ReportRow("কাজের দিন", "${report.workingDays} দিন")
                ReportRow("নিয়মিত বেতন", money(report.regularSalaryTotal))
                ReportRow("মোট OT ঘণ্টা", "${report.totalOvertimeHours} ঘণ্টা")
                ReportRow("OT আয়", money(report.overtimeIncomeTotal))
                ReportRow("বোনাস", money(report.bonusTotal))
                ReportRow("কর্তন", "- ${money(report.deductionTotal)}")
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                ReportRow("মোট আয়", money(report.finalTotalIncome), true)
            }
        }
    }
}

@Composable
private fun ReportRow(label: String, value: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold)
    }
}

@Composable
fun SettingsScreen(viewModel: SalaryViewModel) {
    var salary by remember { mutableStateOf(viewModel.defaultDailySalary.toString()) }
    var otRate by remember { mutableStateOf(viewModel.defaultOvertimeRate.toString()) }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("সেটিংস", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(salary, { salary = it }, label = { Text("ডিফল্ট দৈনিক বেতন") }, prefix = { Text("৳ ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(otRate, { otRate = it }, label = { Text("ডিফল্ট OT রেট / ঘণ্টা") }, prefix = { Text("৳ ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        Button(onClick = {
            viewModel.defaultDailySalary = salary.toDoubleOrNull() ?: 0.0
            viewModel.defaultOvertimeRate = otRate.toDoubleOrNull() ?: 0.0
            saved = true
        }, modifier = Modifier.fillMaxWidth()) { Text("সেভ করুন") }
        if (saved) Text("সেটিংস সেভ হয়েছে", color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 10.dp))
        Spacer(Modifier.height(20.dp))
        Text("এই অ্যাপটি 100% offline। আপনার হিসাব ফোনের ভেতরেই Room/SQLite database-এ সংরক্ষণ হয়।", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDailyEntryDialog(viewModel: SalaryViewModel, onDismiss: () -> Unit, existing: SalaryEntry? = null) {
    var date by remember { mutableStateOf(existing?.date ?: inputDate.format(Date())) }
    var salary by remember { mutableStateOf(existing?.dailySalary?.toString() ?: viewModel.defaultDailySalary.toString()) }
    var otHours by remember { mutableStateOf(existing?.overtimeHours?.toString() ?: "0") }
    var otRate by remember { mutableStateOf(existing?.overtimeRate?.toString() ?: viewModel.defaultOvertimeRate.toString()) }
    var bonus by remember { mutableStateOf(existing?.bonus?.toString() ?: "0") }
    var deduction by remember { mutableStateOf(existing?.deduction?.toString() ?: "0") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var showPicker by remember { mutableStateOf(false) }
    val total = (salary.toDoubleOrNull() ?: 0.0) + (otHours.toDoubleOrNull() ?: 0.0) * (otRate.toDoubleOrNull() ?: 0.0) + (bonus.toDoubleOrNull() ?: 0.0) - (deduction.toDoubleOrNull() ?: 0.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "আজকের হিসাব" else "হিসাব সম্পাদনা") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) { Text(formatDate(date)) }
                Spacer(Modifier.height(8.dp))
                Field("দৈনিক বেতন", salary, { salary = it })
                Field("OT ঘণ্টা", otHours, { otHours = it })
                Field("OT রেট / ঘণ্টা", otRate, { otRate = it })
                Field("বোনাস / Extra", bonus, { bonus = it })
                Field("কর্তন", deduction, { deduction = it })
                Field("নোট", note, { note = it }, number = false)
                Spacer(Modifier.height(8.dp))
                Text("আজকের মোট: ${money(total)}", fontWeight = FontWeight.Bold)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                viewModel.addOrUpdateEntry(
                    id = existing?.id ?: 0L,
                    date = date,
                    salary = salary.toDoubleOrNull() ?: 0.0,
                    otHours = otHours.toDoubleOrNull() ?: 0.0,
                    otRate = otRate.toDoubleOrNull() ?: 0.0,
                    bonus = bonus.toDoubleOrNull() ?: 0.0,
                    deduction = deduction.toDoubleOrNull() ?: 0.0,
                    note = note
                )
                onDismiss()
            }) { Text("সেভ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )

    if (showPicker) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = runCatching { inputDate.parse(date)!!.time }.getOrNull())
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { date = inputDate.format(Date(it)) }
                    showPicker = false
                }) { Text("ঠিক আছে") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("বাতিল") } }
        ) { DatePicker(state = pickerState) }
    }
}

@Composable
private fun Field(label: String, value: String, onValueChange: (String) -> Unit, number: Boolean = true) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        keyboardOptions = if (number) androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal) else androidx.compose.foundation.text.KeyboardOptions.Default
    )
}
