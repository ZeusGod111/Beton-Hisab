package com.betonhisab.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SalaryDao {

    @Query("SELECT * FROM salary_entries ORDER BY date DESC, id DESC")
    fun getAllEntries(): Flow<List<SalaryEntry>>

    @Query("SELECT * FROM salary_entries WHERE date LIKE :monthPrefix || '%' ORDER BY date DESC")
    fun getEntriesByMonth(monthPrefix: String): Flow<List<SalaryEntry>>

    @Query("SELECT * FROM salary_entries WHERE id = :entryId LIMIT 1")
    suspend fun getEntryById(entryId: Long): SalaryEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: SalaryEntry): Long

    @Update
    suspend fun updateEntry(entry: SalaryEntry)

    @Delete
    suspend fun deleteEntry(entry: SalaryEntry)

    @Query("DELETE FROM salary_entries WHERE id = :entryId")
    suspend fun deleteById(entryId: Long)

    @Query("DELETE FROM salary_entries")
    suspend fun clearAll()
}
