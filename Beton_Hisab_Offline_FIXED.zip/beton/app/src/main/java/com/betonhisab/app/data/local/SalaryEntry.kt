package com.betonhisab.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "salary_entries")
data class SalaryEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String,             // Format: "YYYY-MM-DD"
    val dailySalary: Double,      // Basic daily wage (৳)
    val overtimeHours: Double,    // Overtime hours worked
    val overtimeRate: Double,     // Rate per hour (৳)
    val bonus: Double = 0.0,      // Extra allowance / bonus (৳)
    val deduction: Double = 0.0,  // Penalty / advance deduction (৳)
    val note: String = "",        // Optional notes / shift info
    val createdAt: Long = System.currentTimeMillis()
) {
    // Overtime Pay = Overtime Hours × Overtime Rate
    val overtimePay: Double
        get() = overtimeHours * overtimeRate

    // Daily Total = Daily Salary + Overtime Pay + Bonus - Deduction
    val dailyTotal: Double
        get() = dailySalary + overtimePay + bonus - deduction
}
