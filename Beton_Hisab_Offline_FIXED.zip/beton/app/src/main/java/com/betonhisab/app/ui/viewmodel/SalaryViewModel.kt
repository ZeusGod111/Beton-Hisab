package com.betonhisab.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.betonhisab.app.data.local.BetonDatabase
import com.betonhisab.app.data.local.SalaryEntry
import com.betonhisab.app.data.repository.SalaryRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class MonthlyReport(
    val workingDays: Int = 0,
    val regularSalaryTotal: Double = 0.0,
    val totalOvertimeHours: Double = 0.0,
    val overtimeIncomeTotal: Double = 0.0,
    val bonusTotal: Double = 0.0,
    val deductionTotal: Double = 0.0,
    val finalTotalIncome: Double = 0.0
)

class SalaryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SalaryRepository
    val allEntries: StateFlow<List<SalaryEntry>>

    // Selected month in "YYYY-MM" format
    private val _selectedMonth = MutableStateFlow(getCurrentMonthKey())
    val selectedMonth: StateFlow<String> = _selectedMonth.asStateFlow()

    // Default settings stored in SharedPreferences
    private val prefs = application.getSharedPreferences("beton_prefs", Application.MODE_PRIVATE)
    
    var defaultDailySalary: Double
        get() = prefs.getFloat("default_daily_salary", 800f).toDouble()
        set(value) = prefs.edit().putFloat("default_daily_salary", value.toFloat()).apply()

    var defaultOvertimeRate: Double
        get() = prefs.getFloat("default_ot_rate", 100f).toDouble()
        set(value) = prefs.edit().putFloat("default_ot_rate", value.toFloat()).apply()

    init {
        val db = BetonDatabase.getDatabase(application)
        repository = SalaryRepository(db.salaryDao())
        allEntries = repository.allEntries.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    val currentMonthEntries: StateFlow<List<SalaryEntry>> = combine(allEntries, _selectedMonth) { entries, month ->
        entries.filter { it.date.startsWith(month) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val monthlyReport: StateFlow<MonthlyReport> = currentMonthEntries.map { list ->
        var regular = 0.0
        var otHours = 0.0
        var otIncome = 0.0
        var bonus = 0.0
        var deduction = 0.0
        var days = 0

        list.forEach { item ->
            regular += item.dailySalary
            otHours += item.overtimeHours
            otIncome += item.overtimePay
            bonus += item.bonus
            deduction += item.deduction
            if (item.dailySalary > 0 || item.overtimeHours > 0) {
                days++
            }
        }

        val finalTotal = regular + otIncome + bonus - deduction
        MonthlyReport(
            workingDays = days,
            regularSalaryTotal = regular,
            totalOvertimeHours = otHours,
            overtimeIncomeTotal = otIncome,
            bonusTotal = bonus,
            deductionTotal = deduction,
            finalTotalIncome = finalTotal
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MonthlyReport())

    fun setSelectedMonth(monthKey: String) {
        _selectedMonth.value = monthKey
    }

    fun shiftMonth(delta: Int) {
        val cal = Calendar.getInstance().apply {
            time = SimpleDateFormat("yyyy-MM", Locale.US).parse(_selectedMonth.value) ?: Date()
            add(Calendar.MONTH, delta)
        }
        _selectedMonth.value = SimpleDateFormat("yyyy-MM", Locale.US).format(cal.time)
    }

    fun addOrUpdateEntry(
        id: Long = 0,
        date: String,
        salary: Double,
        otHours: Double,
        otRate: Double,
        bonus: Double,
        deduction: Double,
        note: String
    ) = viewModelScope.launch {
        val entry = SalaryEntry(
            id = id,
            date = date,
            dailySalary = salary,
            overtimeHours = otHours,
            overtimeRate = otRate,
            bonus = bonus,
            deduction = deduction,
            note = note
        )
        if (id == 0L) {
            repository.insert(entry)
        } else {
            repository.update(entry)
        }
    }

    fun deleteEntry(entry: SalaryEntry) = viewModelScope.launch {
        repository.delete(entry)
    }

    companion object {
        fun getCurrentMonthKey(): String {
            val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
            return sdf.format(Date())
        }
    }
}
