# বেতন হিসাব (Beton Hisab)

A native Android app for tracking daily salary, overtime, bonus and deductions.

## Offline
- 100% local/offline operation after installation.
- Salary records are stored on-device using Room (SQLite).
- No Firebase, cloud database, API, or internet permission is used.
- Dashboard, history, reports, add/edit/delete and settings work offline.

## Build
Open this folder in Android Studio or a compatible AndroidIDE environment, allow Gradle sync, then build:

```text
./gradlew assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`
